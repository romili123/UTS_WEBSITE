<?php
$host = "localhost"; //nama host
$user = "root"; //username
$pass = ""; //password
$db   = "web"; //nama database
$connect = mysqli_connect($host, $user, $pass, $db);
 ?>
 