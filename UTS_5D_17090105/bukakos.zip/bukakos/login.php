<?php 

require_once("config.php");

session_start();
require_once("koneksi1.php");

if(isset($_POST['login'])){
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = $_POST['password']; 
   // $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);//
    $sql = "SELECT * FROM users WHERE username='". $username . "'";
    $stmt = mysqli_query($connect,$sql);
    if ($stmt->num_rows != 0) {
        $res = mysqli_fetch_assoc($stmt);
        if (password_verify($password, $res['password'])) {
            if ($res['level'] == 'admin') {
                $_SESSION['admin'] = $res;
                header("Location: timeline.php");
            }else if($res['level'] == 'user'){
                $_SESSION['user'] = $res;
                header("Location: halmuser.php");
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login WEB</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">

       

        <h4>Masuk ke WEB</h4>
        <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
<div class="col-md-6">
            <img class="img img-responsive" src="img/masuk.png" />
        </div>
        <form action="" method="POST">

            <div class="form-group">
                <label for="username">Username</label>
                <input class="form-control" type="text" name="username" placeholder="Username atau email" />
            </div>


            <div class="form-group">
                <label for="password">Password</label>
                <input class="form-control" type="password" name="password" placeholder="Password" />
            </div>

            <input type="submit" class="btn btn-success btn-block" name="login" value="Masuk" />

        </form>
            
        </div>

        <div class="col-md-6">
            <!-- isi dengan sesuatu di sini -->
        </div>

    </div>
</div>

    
</body>
</html>