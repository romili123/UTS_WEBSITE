<?php
$koneksi = new mysqli('localhost', 'root', '','web2');

if ($koneksi->connect_error) {
    die("Koneksi Gagal: " . $koneksi->connect_error);
} 
?>