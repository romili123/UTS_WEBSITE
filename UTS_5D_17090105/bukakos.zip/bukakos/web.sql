-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Nov 2019 pada 01.15
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_blog`
--

CREATE TABLE `tb_blog` (
  `id` int(11) NOT NULL,
  `Namakos` varchar(225) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `fasilitas` varchar(50) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no` varchar(50) NOT NULL,
  `harga` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tb_blog`
--

INSERT INTO `tb_blog` (`id`, `Namakos`, `foto`, `fasilitas`, `alamat`, `no`, `harga`) VALUES
(0, 'BERKAH JAYA', 'kos0.jpg', 'AC , lemari, meja, kamar mandi dalam', 'jl paketiban', '089669533511', 'Rp. 400000'),
(1, 'KOST PUTRA', 'kos3.jpg', 'kamar mandi dalam', 'kae', '11112222', 'Rp. 450000'),
(2, 'INDEKOS', 'kos4.jpg', 'kamar mandi dalam, AC', 'jl Mataram', '089647534342', 'Rp.450000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT 'default.svg',
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `name`, `photo`, `level`) VALUES
(1, 'septian', 'septian.adi19@yahoo.co.id', '$2y$10$8F89orR1ZLH0CIeqbN7V2OJAlno/ATUbIySaeZAwfH1DYHL9DbMre', 'septiyan Adi', 'default.svg', 'admin'),
(2, 'romili', 'romiley.madafaka@gmail.com', '$2y$10$V8hRTDVIt6NjSI2MvROSc.V6q2LHZlWjQsmbE/4nkeMWSqNfPP/dO', 'romili', 'default.svg', 'user'),
(3, 'adi', 'adi@gmail.com', '$2y$10$FQhXrWfIi.y2Ax0QRCmfCOAA/eVO.j9db4R2gJtjqQbNkdQ96QfF2', 'adi', 'default.svg', 'user'),
(6, 'adit', 'adit@gmail.com', '$2y$10$xyw9cjMxzrbUkA/BGcm/Zuj321Fg6K3pDJwOHYku9AebjRQj169X6', 'adit', 'default.svg', 'user');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_blog`
--
ALTER TABLE `tb_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
