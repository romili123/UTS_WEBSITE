<?php
require_once('koneksi.php');
if($_POST){

	$sql = "UPDATE tb_blog SET id='".$_POST['id']."', Namakos='".$_POST['Namakos']."', foto='".$_POST['foto']."', fasilitas='".$_POST['fasilitas']."', alamat='".$_POST['alamat']."',no='".$_POST['no']."' WHERE id=".$_POST['id'];

	if ($koneksi->query($sql) === TRUE) {
	    echo "<script>
	alert('Data berhasil di update');
	window.location.href='index1.php?page=crud/index';
	</script>";
	} else {
	    echo "Gagal: " . $koneksi->error;
	}

	$koneksi->close();
	
}else{
	$query = $koneksi->query("SELECT * FROM tb_blog WHERE id=".$_GET['id']);

	if($query->num_rows > 0){
		$data = mysqli_fetch_object($query);
	}else{
		echo "data tidak tersedia";
		die();
	}
?>
<div class="row">
	<div class="col-lg-6">
		<form action="" method="POST">
			<input type="hidden" name="id" value="<?= $data->id ?>">
			<div class="form-group">
				<label>ID</label>
				<input type="text" value="<?= $data->id ?>" class="form-control" name="id">
			</div>
			<div class="form-group">
				<label>Nama Kos</label>
				<input type="text" value="<?= $data->Namakos ?>" class="form-control" name="Namakos">
			</div>
			<div class="form-group">
				<label>FOTO</label>
				<input type="text" value="<?= $data->foto ?>" class="form-control" name="foto">
			</div>
			<div class="form-group">
				<label>Fasilitas</label>
				<input type="text" value="<?= $data->fasilitas ?>" class="form-control" name="fasilitas">
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<input type="text" value="<?= $data->alamat ?>" class="form-control" name="alamat">
			</div>
			<div class="form-group">
				<label>NO HP</label>
				<input type="text" value="<?= $data->no ?>" class="form-control" name="no">
			</div>
			<input type="submit" class="btn btn-primary btn-sm" name="Update" value="Update">
		</form>
	</div>
</div>
<?php
}
mysqli_close($koneksi);
?>