<?php
require_once('koneksi.php');
if($_POST){
	try {
		$sql = "INSERT INTO tb_blog (id,Namakos,foto,fasilitas,alamat,no) VALUES ('".$_POST['id']."','".$_POST['Namakos']."','".$_POST['foto']."','".$_POST['fasilitas']."','".$_POST['alamat']."','".$_POST['no']."')";
		if(!$koneksi->query($sql)){
			echo $koneksi->error;
			die();
		}

	} catch (Exception $e) {
		echo $e;
		die();
	}
	  echo "<script>
	alert('Data berhasil di simpan');
	window.location.href='index1.php?page=crud/index';
	</script>";
}
?>
<div class="row">
	<div class="col-lg-6">
		<form action="" method="POST">
			<div class="form-group">
				<label>ID</label>
				<input type="text" value="" class="form-control" name="id">
			</div>
			<div class="form-group">
				<label>Nama Kos</label>
				<input type="text" value="" class="form-control" name="Namakos">
			</div>
			<div class="form-group">
				<label>Fasilitas</label>
				<textarea name="fasilitas" rows="7" cols="75"></textarea>
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<textarea name="alamat" rows="7" cols="75"></textarea>
			</div>
			<div class="form-group">
				<label>NO HP</label>
				<input type="text" value="" class="form-control" name="no">
			</div>
			<div class="form-group">
				<label>Foto</label>
				<input type="file" value="" name="foto">
			</div>
			<input type="submit" class="btn btn-primary btn-sm" name="create" value="Create">
		</form>
	</div>
</div>