<?php require_once("auth.php"); ?>
<?php require 'koneksi1.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php require 'koneksi.php'; ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-danger fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Admin</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a href="#" class="nav-link"> Beranda
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <ul class="nav nav-pills">
                    <li class="nav-item">
                       
                        <a class="nav-link active" href="index1.php">CRUD</a>
                    </li>
                </ul>
                </ul>
            </div>
        </div>
    </nav>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">

            <div class="card">
                <div class="card-body text-center">

                    <img class="img img-responsive rounded-circle mb-3" width="160" src="img/<?php echo $_SESSION['user']['photo'] ?>" />
                    
                    <h3><?php echo  $_SESSION["admin"]["name"] ?></h3>
                    <p><?php echo $_SESSION["admin"]["email"] ?></p>

                    <p><a href="logout.php">keluar</a></p>
                    </div>
            </div>

            
        </div>


        <div class="col-md-8">

            
            <?php
            $query = "SELECT * FROM tb_blog";
            $sql = mysqli_query($connect,$query);
            while ($data= mysqli_fetch_array($sql)){
            ?>
        
<!--Blog Post-->
               <div class="card mb-4">
                <img class="card-img-top" src="img/<?php echo $data['foto'] ?>" alt="Card image cap">
                 <div class="card-body">
                    <h2 class="card-title"><?php echo $data['Namakos'] ?></h2>
                    <p class="card-text"><?php echo $data['fasilitas'] ?></p>
                     <p class="card-text"><?php echo $data['alamat'] ?></p>
                     <!-- <p class="card-text"><?php echo $data['no'] ?></p> -->
                    
                    </div>
                    
                </div>
            <?php } ?>

  <!--          <?php for($i=0; $i < 1; $i++){ ?>
            <div class="card mb-3">
                <img class="card-img-top" src="img/kos0.jpg" alt="card image cap">
                <div class="card-body">
              <h2 class="card-tittle">Valencia Jaya 9</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, AC, kasur, lemari, meja belajar, wifi</p>
                    <p class="card-text">Di sewa Dengan Harga : Rp 1.500.000 </p>
                    <p class="card-text">Alamat: Jakarta Barat, Jakarta D.K.I.  </p>
                     <p class="card-text">No HP : 082311444888   </p>
              </div>
   --><!--         </div>
            <?php } ?>
             <div class="card mb-3">
                <img class="card-img-top" src="img/kos3.jpg" alt="card image cap">
                <div class="card-body">
                 <h2 class="card-tittle">Kos Putri Indah</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, Kipas, kasur, lemari </p>
                    <p class="card-text">Di sewa Dengan Harga : Rp 600.000 </p>
                    <p class="card-text">   Jakarta Timur, Jakarta D.K.I.   </p>
                     <p class="card-text">No HP : 081806800931   </p>
                    <a href="#" class="btn btn-primary">Read More &rarr;</a>
                </div>
            </div>

    --> <!--        <div class="card mb-3">
                <img class="card-img-top" src="img/kos4.jpg" alt="card image cap">
                <div class="card-body">
                 <h2 class="card-tittle">The One Kost</h2>
                     <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, AC, kasur, lemari, Rak Buku </p>
                    <p class="card-text">Di sewa Dengan Harga : Rp 800.000 </p>
                    <p class="card-text">   Perumahan Tana Tidar Unit A3 jl Raya Candi 6 C no 12 Malang (Sebrangnya perumahan Greenland)   </p>
                     <p class="card-text">No HP : Yohana Larasati / 082131226999   </p>
                    <a href="#" class="btn btn-primary">Read More &rarr;</a>
                </div>
            </div>
-->
       <!--Blog Post-->
      <!--      <div class="card mb-4">
                <img class="card-img-top" src="img/kos5.jpg" alt="card image cap">
                <div class="card-body">
                    <h2 class="card-tittle">Mami Kos</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, kipas, kasur, lemari, meja belajar, wifi</p>
                    <p class="card-text">Di sewa Dengan Harga : 700 ribu</p>
                    <a href="#" class="btn btn-primary">Read More &rarr;</a>
                </div>
                <div class="card-footer text-outed">
                    Posted on Juni 17, 2019 by
                    <a href="#">Admin</a>
                </div>
            </div>

       -->     <!--Blof Post-->
    <!--        <div class="card mb-4">
                <img src="img/kos1.jpg" alt="Card image cap" class="card-img-top">
                <div class="card-body">
                    <h2 class="card-tittle">Nama Kos Berkah jaya</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, kipas, kasur, lemari</p>
                    <p class="card-text">Di sewa Dengan Harga : 600 ribu</p>
                    <p class="card-text">Alamat: Jl.Mataram samping Kampus Politeknik Harber Tegal   </p>
                     <p class="card-text">No HP : ENI / 081331425567   </p>
                    <a href="#" class="btn btn-primary"> Read more &rarr;</a>
                </div>
                <div class="card-footer text-muted">
                    Posted on Juni 17, 2019 by
                    <a href="#">Admin</a>
              -->  </div>
            </div>
        </div>

        </div>

    </div>
</div>

<!-- Footer -->
<footer class="py-5 bg-primary">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; BUKA KOST OFFICIAL 2019</p>
    </div>
</footer>

</body>
</html>