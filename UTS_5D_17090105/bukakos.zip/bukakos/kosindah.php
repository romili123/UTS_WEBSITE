<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>Kos Indah Putri</title>
    
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-success fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Kos Indah Putri</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
           
        </div>
    </nav>

    <div class="card mb-4">
                <img class="card-img-center" src="img/kos1.jpg" alt="card image cap">
                <div class="card-body">
                    <h2 class="card-tittle">KOS INDAH PUTRI</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, kipas, kasur, lemari, meja belajar, wifi</p>
                    <p class="card-text">Di sewa Dengan Harga : 700 ribu</p>
                    <a href="#" class="btn btn-primary">Pesan Sekarang &rarr;</a>
                </div>
            </div>
</body>
</html>