<?php

session_start();
function isAdminLogin(){
	if(!isset($_SESSION['admin'])) header("Location: login.php");
}

function isUserLogin(){
	if(!isset($_SESSION['user'])) header("Location: login.php");
}