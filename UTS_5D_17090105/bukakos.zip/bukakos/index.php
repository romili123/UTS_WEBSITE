<?php require_once("auth.php"); ?>
<?php require_once 'koneksi1.php'; ?>
<?php isUserLogin()?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="bg-light"><center>

<nav class="navbar navbar-expand-lg navbar-dark bg-success fixed-top">
        
                        <a style="color: white;" href="http://localhost/bukakos/index.php?" class="nav-link"> BukaKos
                            <span class="sr-only">(current)</span>
                        </a>
                        <div class="collapse navbar-collapse" id="navbarResponsive">

                        <ul class="navbar-nav ml-auto">
                        
                            <li class"nav-item active">
                             <form action="index.php" method="get">
                                
                            <label style="color: white;">Pencarian:</label>
                             <input type="text" name="cari">
                             
                             </li>

                <ul class="navbar-nav ml-auto">
                        
                    <li class="nav-item active">
                        <a href="register.php" class="nav-link active"> Daftar
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <ul class="nav nav-pills">

                    <li class="nav-item">
                       
                        <a class="nav-link active" href="login.php">Masuk</a>
                    </li>
                    </div>
                   
    </nav>
   
    
        <?php 
if(isset($_GET['cari'])){
    $cari = $_GET['cari'];
    $sql = "SELECT * FROM tb_blog WHERE alamat LIKE '%{$cari}%' OR fasilitas LIKE '%{$cari}%'";
    $res = mysqli_query($connect,$sql);
    $dt = mysqli_fetch_array($res);
}
?></form>

<div class="container mt-5">
    <div class="row">
   


        <div class="col-md-8">

            <form action="" method="post" />
              <!--  <div class="form-group">
                    <textarea class="form-control" placeholder="Silahkan pilih kost"></textarea>
                </div>
            -->
            </form>
            <?php if (is_array(@$dt)) : ?>
                <div class="card mb-4"><center>
                <img class="card-img-top" src="img/<?php echo $dt['foto'] ?>" alt="Card image cap">
                <div class="card-body">
                    <h2 class="card-title"><?php echo $dt['Namakos'] ?></h2>
                    <p class="card-text"><?php echo $dt['fasilitas'] ?></p>
                     <p class="card-text"><?php echo $dt['alamat'] ?></p>
                     <p class="card-text"><?php echo $dt['no'] ?></p>
                     <a href="#" class="btn btn-primary">Pesan Sekarang&rarr;</a>
                    </div>
                    
                </center></div>
            <?php else:?>
                <?php 
                    $query = "SELECT * FROM tb_blog";
                    $sql = mysqli_query($connect,$query);?>
                    <?php while ($data= mysqli_fetch_array($sql)) :?>
                        <div class="card mb-4">
                <img class="card-img-top" src="img/<?php echo $data['foto'] ?>" alt="Card image cap">
                <div class="card-body">
                    <h2 class="card-title"><?php echo $data['Namakos'] ?></h2>
                    <p class="card-text"><?php echo $data['fasilitas'] ?></p>
                     <p class="card-text">Alamat : <?php echo $data['alamat'] ?></p>
                     
                     <a href="login.php" class="btn btn-primary">PESAN SEKARANG&rarr;</a>

                    </div>
                    
                </div>
                    <?php endwhile;?>
            <?php endif; ?>
           <!-- <?php
            $query = "SELECT * FROM tb_blog";
            $sql = mysqli_query($connect,$query);
            while ($data= mysqli_fetch_array($sql)){
            ?> -->
        
<!--Blog Post-->
            
            <!-- <?php } ?> -->

          <!--  <?php for($i=0; $i < 1; $i++){ ?>
            <div class="card mb-3">
                <img class="card-img-top" src="img/kos0.jpg" alt="card image cap">
                <div class="card-body">
              <h2 class="card-tittle">Valencia Jaya 9</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, AC, kasur, lemari, meja belajar, wifi</p>
                    <p class="card-text">Di sewa Dengan Harga : Rp 1.500.000 </p>
                    <p class="card-text">Alamat: Jakarta Barat, Jakarta D.K.I.  </p>
                     <p class="card-text">No HP : 082311444888   </p>
                </div>
            </div>
            <?php } ?>
             <div class="card mb-3">
                <img class="card-img-top" src="img/kos3.jpg" alt="card image cap">
                <div class="card-body">
                 <h2 class="card-tittle">Kos Putri Indah</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, Kipas, kasur, lemari </p>
                    <p class="card-text">Di sewa Dengan Harga : Rp 600.000 </p>
                    <p class="card-text">   Jakarta Timur, Jakarta D.K.I.   </p>
                     <p class="card-text">No HP : 081806800931   </p>
                    <a href="#" class="btn btn-primary">Read More &rarr;</a>
                </div>
            </div>

             <div class="card mb-3">
                <img class="card-img-top" src="img/kos4.jpg" alt="card image cap">
                <div class="card-body">
                 <h2 class="card-tittle">The One Kost</h2>
                     <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, AC, kasur, lemari, Rak Buku </p>
                    <p class="card-text">Di sewa Dengan Harga : Rp 800.000 </p>
                    <p class="card-text">   Perumahan Tana Tidar Unit A3 jl Raya Candi 6 C no 12 Malang (Sebrangnya perumahan Greenland)   </p>
                     <p class="card-text">No HP : Yohana Larasati / 082131226999   </p>
                    <a href="#" class="btn btn-primary">Read More &rarr;</a>
                </div>
            </div>
-->
       <!--Blog Post-->
       <!--     <div class="card mb-4">
                <img class="card-img-top" src="img/kos5.jpg" alt="card image cap">
                <div class="card-body">
                    <h2 class="card-tittle">Mami Kos</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, kipas, kasur, lemari, meja belajar, wifi</p>
                    <p class="card-text">Di sewa Dengan Harga : 700 ribu</p>
                    <a href="#" class="btn btn-primary">Read More &rarr;</a>
                </div>
                <div class="card-footer text-outed">
                    Posted on Juni 17, 2019 by
                    <a href="#">Admin</a>
                </div>
            </div>
-->
            <!--Blof Post-->
     <!--       <div class="card mb-4">
                <img src="img/kos1.jpg" alt="Card image cap" class="card-img-top">
                <div class="card-body">
                    <h2 class="card-tittle">Nama Kos Berkah jaya</h2>
                    <p class="card-text">Fasilitas :</p>
                    <p class="card-text">Kamar mandi dalam, kipas, kasur, lemari</p>
                    <p class="card-text">Di sewa Dengan Harga : 600 ribu</p>
                    <p class="card-text">Alamat: Jl.Mataram samping Kampus Politeknik Harber Tegal   </p>
                     <p class="card-text">No HP : ENI / 081331425567   </p>
                    <a href="#" class="btn btn-primary"> Read more &rarr;</a>
                </div>
                <div class="card-footer text-muted">
                    Posted on Juni 17, 2019 by
                    <a href="#">Admin</a>
            -->    </div>
            </div>
        </div>

        </div>
    
    </div>
</div>
 <!--<div class="container-fluid bg-grey">
  <h2 class="text-center">Kontak</h2>
  <div class="row">
    <div class="col-sm-5">
      <p>Silahkan Hubungi Admin</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Jakarta, Indonesia</p>
      <p><span class="glyphicon glyphicon-phone"></span> (022) 73518475</p>
      <p><span class="glyphicon glyphicon-envelope"></span> kukuh83@gmail.com</p>
    </div>
    <div class="col-sm-7">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" type="submit">Send</button>
        </div>
      </div>
    </div>
  </div>
</div>--> 
<!-- Footer -->
<footer class="py-5 bg-primary">
    <div class="container">
        <p class="m-0 text-center text-white">TENTANG KAMI HUB : 0895806682667</p>
    </div>
</footer>

</body>
</html>