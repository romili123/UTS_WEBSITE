<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>Berkah jaya Kos</title>
    
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-success fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">User</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a href="http://localhost/bukakos/halmuser.php?" class="nav-link"> Halaman Kos
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                       
                    </li>
                </ul>
            </div>
        </div>
    </nav>

<?php 
$conn = mysqli_connect("localhost", "root", "", "web");
                    function query($query){
                    global $conn;
                    $result = mysqli_query($conn, $query);
                    $rows = [];
                    while ($row= mysqli_fetch_assoc($result)){
                        $rows[] = $row;
                    }
                        return $rows;
                    }

?>

<?php
$id = $_GET["id"];


$data = query("SELECT * FROM tb_blog WHERE id = $id")[0];



 ?>





<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">

            <div class="card">
                <div class="card-body text-center">
<ul>

<br><b><?= $data["Namakos"]; ?>
</ul>

<ul>

<br>Alamat : <?= $data["alamat"]; ?>
</ul>

<ul>

<br>Fasilitas : <?= $data["fasilitas"]; ?>
</ul>

<ul>

<br>Nomor HP : <?= $data["no"]; ?>
</ul>

<ul>
<br>Harga / Bulan : <?= $data["harga"]; ?>
</ul>

                </div>
            </div>

            
        </div>


<img align="center" src="img/<?php echo $data["foto"]; ?>" width="500px" height="400px">
<div class="container mt-5"><div class="row">
        


</body>
</html>